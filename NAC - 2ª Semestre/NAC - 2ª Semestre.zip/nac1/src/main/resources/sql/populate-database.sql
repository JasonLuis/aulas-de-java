INSERT INTO TB_LOJA (ID, NOME_LOJA, URL) VALUES (LOJA_SEQ.NEXTVAL, 'Americanas', 'www.americas.com.br');
INSERT INTO TB_LOJA (ID, NOME_LOJA, URL) VALUES (LOJA_SEQ.NEXTVAL, 'Fast Shop', 'www.fastshop.com.br');
INSERT INTO TB_LOJA (ID, NOME_LOJA, URL) VALUES (LOJA_SEQ.NEXTVAL, 'Magazine Luiza', 'www.magazine.com.br');
INSERT INTO TB_LOJA (ID, NOME_LOJA, URL) VALUES (LOJA_SEQ.NEXTVAL, 'Submarino', 'www.submarino.com.br');

